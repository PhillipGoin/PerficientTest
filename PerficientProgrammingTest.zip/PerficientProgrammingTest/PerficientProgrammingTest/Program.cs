﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FizzBuzz;


namespace PerficientProgrammingTest
{
    class Program
    {
        static void Main(string[] args)
        {
            FizzBuzzParameters parameters = new FizzBuzzParameters();
            try
            {
                parameters.ParseParameters(args);
                int size = parameters.top - parameters.bottom;
                if (size> 100000)
                {
                    StringBuilder sb = FizzBuzz.FizzBuzz.BatchedFizzBuzz(parameters);
                    Console.Out.Write(sb.ToString());
                }
                else
                {
                    string result = FizzBuzz.FizzBuzz.fullFizzBuzz(parameters);
                    Console.Out.Write(result);
                }
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.Out.Write(ex.Message);
                Console.ReadLine();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;

namespace FizzBuzz
{
    /// <summary>
    /// Used to define FizzBuzz parameters
    /// </summary>
    public class FizzBuzzParameters
    {
        public int bottom { get; set; }
        public int top { get; set; }
        public Dictionary<string, string>words { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public FizzBuzzParameters()
        {
            words = new Dictionary<string, string>();
            top = -1;
            bottom = -1;
        }

        /// <summary>
        /// Full Constructor
        /// </summary>
        /// <param name="bottom">First Number to run.</param>
        /// <param name="top">Last Number to run.</param>
        /// <param name="words">Dictionary of string, string where the first string is the word to append, and the second is the number to append it on.</param>
        public FizzBuzzParameters(int bottom, int top, Dictionary<string, string> words)
        {
            this.words = words;
            this.top = top;
            this.bottom = bottom;
        }

        /// <summary>
        /// Used to parse out a JSON string to parameters.
        /// </summary>
        /// <param name="args">string array typically found in a main method.</param>
        public void ParseParameters(string[] args)
        {
            JavaScriptSerializer js = new JavaScriptSerializer();
            var serializer = new DataContractJsonSerializer(typeof(FizzBuzzParameters));
            string json = "";
            
            foreach (string arg in args)
            {
                json += arg;
            }
            FizzBuzzParameters parameters = new FizzBuzzParameters();
            try
            {
                json = json.Replace('\'', '\"');
                var stream = new MemoryStream(Encoding.UTF8.GetBytes(json));
                //parameters = (FizzBuzzParameters)js.Deserialize(json, typeof(FizzBuzzParameters));
                parameters = (FizzBuzzParameters)serializer.ReadObject(stream);
            }
            catch (Exception ex)
            {
                throw new Exception("Parameter was not formed correctly: format should be JSON like this" + "{'bottom': 1, 'top': 100, 'words': [{ 'Key':'Fizz','Value': 3},{ 'Key':'Buzz', 'Value': 5} ]}");
            }

            Process(parameters);
        }

        /// <summary>
        /// Used to populate this object from an existing FizzBuzzParameter object.
        /// </summary>
        /// <param name="parameters">Parameter object</param>
        private void Process(FizzBuzzParameters parameters)
        {
            //Now we have to decide what the user wants to do.
            this.bottom = parameters.bottom;
            this.top = parameters.top;
            this.words = parameters.words;
        }
    }
}

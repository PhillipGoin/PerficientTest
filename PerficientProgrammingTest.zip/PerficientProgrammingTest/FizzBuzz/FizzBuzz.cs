﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzz
{
    public static class FizzBuzz
    {
        /// <summary>
        /// Used to create a Dictionary of Numbers and the words that are divisible with no remainder
        /// based upon the FizzBuzzParameters passed in.
        /// </summary>
        /// <param name="param">Parameters to Apply</param>
        /// <returns>A dictionary of string, string that represent the results of the matching.</returns>
        public static string fullFizzBuzz(FizzBuzzParameters param)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                for (int i = param.bottom; i <= param.top; i++)
                {
                    string word = "";
                    // KeyValuePair is Word, Value Fizz, 3 or Buzz, 5
                    foreach (KeyValuePair<string, string> p in param.words)
                    {

                        long val = long.Parse(p.Value);
                        if (i % val == 0)
                        {
                            word += p.Key;
                        }
                    }
                    sb.Append(i.ToString() + word + "\r\n");
                }
            }
            catch (Exception ex)
            {
                string foo = ex.Message;
            }
            return sb.ToString();
        }

        /// <summary>
        /// Used to handle very Large sets of numbers without using up system resources.
        /// </summary>
        /// <param name="param">FizzBuzz Parameters to use.</param>
        /// <returns>StringBuilder containing the result string.</returns>
        public static StringBuilder BatchedFizzBuzz(FizzBuzzParameters param)
        {
            StringBuilder sb = new StringBuilder();
            FizzBuzzParameters p = new FizzBuzzParameters();
            string results = FizzBuzz.fullFizzBuzz(param);
            sb.Append(results);
            return sb;
        }


        /// <summary>
        /// Used to determine the Ceilling of the Batch. Since we could have either a full batch or less than a full batch
        /// we need to determine what to set the top property of the FizzBuzzParameters value to.
        /// </summary>
        /// <param name="batching">boolean are we batching?</param>
        /// <param name="i">int for the iteration index</param>
        /// <param name="remainder">remainder if we are batching or the total number of numbers we are walking.</param>
        /// <param name="floor">the starting number to process.</param>
        /// <param name="BatchSize">what size of batches are we working with.</param>
        /// <returns>the correct integer value based upon the criteria.</returns>
        private static int SetCeilling(bool batching, int i, int lastFullBatch, long remainder, long floor, int BatchSize, long maxValue)
        {
            int top = (int)floor;
            if (i < lastFullBatch - 1 && batching)
            {
                top = (int)floor + BatchSize;
            }
            else if (i == lastFullBatch - 1 && batching)
            {
                top = (int)(floor + remainder);
            }
            else if (!batching)
            {
                top = (int)(floor + remainder);
            }
            if (top > maxValue)
            {
                top = (int)maxValue;
            }
            return top;
        }

        /// <summary>
        /// Used to determine if there is a remainder and determine the quotient of the minVal to maxVal divided by the Batch Size
        /// </summary>
        /// <param name="maxVal">Last number in the sequence.</param>
        /// <param name="minVal">First number in the sequence.</param>
        /// <param name="BatchSize">number of records used in the batch.</param>
        /// <param name="quotient">Integer value of the division</param>
        /// <returns>remainder portion of the division</returns>
        private static long DetermineRemainder(long maxVal, long minVal, int BatchSize, ref long quotient)
        {
            long val = maxVal - minVal;
            long remainder;
            quotient = Math.DivRem(val, BatchSize, out remainder);
            return remainder;
        }

        /// <summary>
        /// Used create a StringBuilder to create the output string from the results..
        /// </summary>
        /// <param name="results">Dictionary<string, string> of Numbers, Words to append.</param>
        /// <returns>String representation of the results.</returns>
        private static string BuildOutPut(Dictionary<string, string> results)
        {
            StringBuilder sb = new StringBuilder();
            foreach (KeyValuePair<string, string> p in results)
            {
                sb.Append(p.Key.ToString() + p.Value + Environment.NewLine);
            }
            return sb.ToString();
        }
    }
}

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FizzBuzz;
using System.Collections.Generic;
using System.Text;

namespace PerficientProgrammingTestUnitTest
{
    /// <summary>
    /// Unit Test for FizzBuzz
    /// </summary>
    [TestClass]
    public class UnitTestFizzBuzz
    {
        /// <summary>
        /// Used to test Test FizzBuzz Parameter object.
        /// </summary>
        [TestMethod]
        public void TestCreateParameters()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 100;
            param.bottom = 1;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Fizz", "3");
            words.Add("Buzz", "5");
            param.words = words;
            Assert.AreEqual(100, param.top);
            Assert.AreEqual(1, param.bottom);
            Assert.AreEqual(words, param.words);
        }

        /// <summary>
        /// Used to test Case 1
        /// </summary>
        [TestMethod]
        public void TestCase1()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 100;
            param.bottom = 1;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Fizz", "3");
            words.Add("Buzz", "5");
            param.words = words;
            Assert.AreEqual(100, param.top);
            Assert.AreEqual(1, param.bottom);
            Assert.AreEqual(words, param.words);
            string results = @"1
2
3Fizz
4
5Buzz
6Fizz
7
8
9Fizz
10Buzz
11
12Fizz
13
14
15FizzBuzz
16
17
18Fizz
19
20Buzz
21Fizz
22
23
24Fizz
25Buzz
26
27Fizz
28
29
30FizzBuzz
31
32
33Fizz
34
35Buzz
36Fizz
37
38
39Fizz
40Buzz
41
42Fizz
43
44
45FizzBuzz
46
47
48Fizz
49
50Buzz
51Fizz
52
53
54Fizz
55Buzz
56
57Fizz
58
59
60FizzBuzz
61
62
63Fizz
64
65Buzz
66Fizz
67
68
69Fizz
70Buzz
71
72Fizz
73
74
75FizzBuzz
76
77
78Fizz
79
80Buzz
81Fizz
82
83
84Fizz
85Buzz
86
87Fizz
88
89
90FizzBuzz
91
92
93Fizz
94
95Buzz
96Fizz
97
98
99Fizz
100Buzz
";
            string test = FizzBuzz.FizzBuzz.fullFizzBuzz(param);
            Assert.AreEqual(results, test);
        }

        /// <summary>
        /// Used to test Case 3
        /// </summary>
        [TestMethod]
        public void TestCase3()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 100;
            param.bottom = 1;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Foo", "3");
            words.Add("Bar", "5");
            param.words = words;
            Assert.AreEqual(100, param.top);
            Assert.AreEqual(1, param.bottom);
            Assert.AreEqual(words, param.words);
            string result = @"1
2
3Foo
4
5Bar
6Foo
7
8
9Foo
10Bar
11
12Foo
13
14
15FooBar
16
17
18Foo
19
20Bar
21Foo
22
23
24Foo
25Bar
26
27Foo
28
29
30FooBar
31
32
33Foo
34
35Bar
36Foo
37
38
39Foo
40Bar
41
42Foo
43
44
45FooBar
46
47
48Foo
49
50Bar
51Foo
52
53
54Foo
55Bar
56
57Foo
58
59
60FooBar
61
62
63Foo
64
65Bar
66Foo
67
68
69Foo
70Bar
71
72Foo
73
74
75FooBar
76
77
78Foo
79
80Bar
81Foo
82
83
84Foo
85Bar
86
87Foo
88
89
90FooBar
91
92
93Foo
94
95Bar
96Foo
97
98
99Foo
100Bar
";
            string test = FizzBuzz.FizzBuzz.fullFizzBuzz(param);
            Assert.AreEqual(result, test);
        }

        /// <summary>
        /// Used to test Case 4
        /// </summary>
        [TestMethod]
        public void TestCase4()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 200;
            param.bottom = 100;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Foo", "3");
            words.Add("Bar", "5");
            param.words = words;
            Assert.AreEqual(200, param.top);
            Assert.AreEqual(100, param.bottom);
            Assert.AreEqual(words, param.words);
            string result = @"100Bar
101
102Foo
103
104
105FooBar
106
107
108Foo
109
110Bar
111Foo
112
113
114Foo
115Bar
116
117Foo
118
119
120FooBar
121
122
123Foo
124
125Bar
126Foo
127
128
129Foo
130Bar
131
132Foo
133
134
135FooBar
136
137
138Foo
139
140Bar
141Foo
142
143
144Foo
145Bar
146
147Foo
148
149
150FooBar
151
152
153Foo
154
155Bar
156Foo
157
158
159Foo
160Bar
161
162Foo
163
164
165FooBar
166
167
168Foo
169
170Bar
171Foo
172
173
174Foo
175Bar
176
177Foo
178
179
180FooBar
181
182
183Foo
184
185Bar
186Foo
187
188
189Foo
190Bar
191
192Foo
193
194
195FooBar
196
197
198Foo
199
200Bar
";
            string test = FizzBuzz.FizzBuzz.fullFizzBuzz(param);
            Assert.AreEqual(result, test);
        }

        /// <summary>
        /// Used to test Case 5
        /// </summary>
        [TestMethod]
        public void TestCase5()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 200;
            param.bottom = 100;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Foo", "5");
            words.Add("Bar", "7");
            param.words = words;
            Assert.AreEqual(200, param.top);
            Assert.AreEqual(100, param.bottom);
            Assert.AreEqual(words, param.words);
            string result = @"100Foo
101
102
103
104
105FooBar
106
107
108
109
110Foo
111
112Bar
113
114
115Foo
116
117
118
119Bar
120Foo
121
122
123
124
125Foo
126Bar
127
128
129
130Foo
131
132
133Bar
134
135Foo
136
137
138
139
140FooBar
141
142
143
144
145Foo
146
147Bar
148
149
150Foo
151
152
153
154Bar
155Foo
156
157
158
159
160Foo
161Bar
162
163
164
165Foo
166
167
168Bar
169
170Foo
171
172
173
174
175FooBar
176
177
178
179
180Foo
181
182Bar
183
184
185Foo
186
187
188
189Bar
190Foo
191
192
193
194
195Foo
196Bar
197
198
199
200Foo
";
            string test = FizzBuzz.FizzBuzz.fullFizzBuzz(param);
            Assert.AreEqual(result, test);
        }

        /// <summary>
        /// Used to test Case 6
        /// </summary>
        [TestMethod]
        public void TestCase6()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 200;
            param.bottom = 100;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Foo", "3");
            words.Add("Bar", "5");
            words.Add("Bazz", "7");
            words.Add("Banana", "11");
            param.words = words;
            Assert.AreEqual(200, param.top);
            Assert.AreEqual(100, param.bottom);
            Assert.AreEqual(words, param.words);
            string result = @"100Bar
101
102Foo
103
104
105FooBarBazz
106
107
108Foo
109
110BarBanana
111Foo
112Bazz
113
114Foo
115Bar
116
117Foo
118
119Bazz
120FooBar
121Banana
122
123Foo
124
125Bar
126FooBazz
127
128
129Foo
130Bar
131
132FooBanana
133Bazz
134
135FooBar
136
137
138Foo
139
140BarBazz
141Foo
142
143Banana
144Foo
145Bar
146
147FooBazz
148
149
150FooBar
151
152
153Foo
154BazzBanana
155Bar
156Foo
157
158
159Foo
160Bar
161Bazz
162Foo
163
164
165FooBarBanana
166
167
168FooBazz
169
170Bar
171Foo
172
173
174Foo
175BarBazz
176Banana
177Foo
178
179
180FooBar
181
182Bazz
183Foo
184
185Bar
186Foo
187Banana
188
189FooBazz
190Bar
191
192Foo
193
194
195FooBar
196Bazz
197
198FooBanana
199
200Bar
";
            string test = FizzBuzz.FizzBuzz.fullFizzBuzz(param);
            Assert.AreEqual(result, test);
        }

        /// <summary>
        /// Used to test Case 8a Not Batched
        /// </summary>
        [TestMethod]
        public void TestCase8A()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 200;
            param.bottom = 100;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Foo", "3");
            words.Add("Bar", "5");
            words.Add("Bazz", "7");
            words.Add("Banana", "11");
            param.words = words;
            Assert.AreEqual(200, param.top);
            Assert.AreEqual(100, param.bottom);
            Assert.AreEqual(words, param.words);
            StringBuilder sbResult = new StringBuilder();
            sbResult.Append(@"100Bar
101
102Foo
103
104
105FooBarBazz
106
107
108Foo
109
110BarBanana
111Foo
112Bazz
113
114Foo
115Bar
116
117Foo
118
119Bazz
120FooBar
121Banana
122
123Foo
124
125Bar
126FooBazz
127
128
129Foo
130Bar
131
132FooBanana
133Bazz
134
135FooBar
136
137
138Foo
139
140BarBazz
141Foo
142
143Banana
144Foo
145Bar
146
147FooBazz
148
149
150FooBar
151
152
153Foo
154BazzBanana
155Bar
156Foo
157
158
159Foo
160Bar
161Bazz
162Foo
163
164
165FooBarBanana
166
167
168FooBazz
169
170Bar
171Foo
172
173
174Foo
175BarBazz
176Banana
177Foo
178
179
180FooBar
181
182Bazz
183Foo
184
185Bar
186Foo
187Banana
188
189FooBazz
190Bar
191
192Foo
193
194
195FooBar
196Bazz
197
198FooBanana
199
200Bar
");
            StringBuilder sbTest = FizzBuzz.FizzBuzz.BatchedFizzBuzz(param);
            Assert.AreEqual(sbResult.ToString(), sbTest.ToString());
        }

        /// <summary>
        /// Used to test Case 8B Batched
        /// </summary>
        [TestMethod]
        public void TestCase8B()
        {
            FizzBuzzParameters param = new FizzBuzzParameters();
            Assert.AreNotEqual(null, param);
            param.top = 10000000;
            param.bottom = 1;
            Dictionary<string, string> words = new Dictionary<string, string>();
            words.Add("Foo", "3");
            words.Add("Bar", "5");
            words.Add("Bazz", "7");
            words.Add("Banana", "11");
            param.words = words;
            Assert.AreEqual(10000000, param.top);
            Assert.AreEqual(1, param.bottom);
            Assert.AreEqual(words, param.words);
            
            StringBuilder sbTest = FizzBuzz.FizzBuzz.BatchedFizzBuzz(param);
            Assert.AreNotEqual(null, sbTest.ToString());
            Assert.AreNotEqual("", sbTest.ToString());
        }
    }
}

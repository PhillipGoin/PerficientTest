﻿namespace PerficientFormsVersion
{
    partial class FizzBuzzForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labMinVal = new System.Windows.Forms.Label();
            this.labMaxVal = new System.Windows.Forms.Label();
            this.labWordsAndNumbers = new System.Windows.Forms.Label();
            this.dgvWords = new System.Windows.Forms.DataGridView();
            this.Key = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labOutput = new System.Windows.Forms.Label();
            this.tbOutPut = new System.Windows.Forms.TextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.tbMin = new System.Windows.Forms.TextBox();
            this.tbMax = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWords)).BeginInit();
            this.SuspendLayout();
            // 
            // labMinVal
            // 
            this.labMinVal.AutoSize = true;
            this.labMinVal.Location = new System.Drawing.Point(44, 32);
            this.labMinVal.Name = "labMinVal";
            this.labMinVal.Size = new System.Drawing.Size(81, 13);
            this.labMinVal.TabIndex = 0;
            this.labMinVal.Text = "Minimum Value:";
            // 
            // labMaxVal
            // 
            this.labMaxVal.AutoSize = true;
            this.labMaxVal.Location = new System.Drawing.Point(44, 58);
            this.labMaxVal.Name = "labMaxVal";
            this.labMaxVal.Size = new System.Drawing.Size(84, 13);
            this.labMaxVal.TabIndex = 2;
            this.labMaxVal.Text = "Maximum Value:";
            // 
            // labWordsAndNumbers
            // 
            this.labWordsAndNumbers.AutoSize = true;
            this.labWordsAndNumbers.Location = new System.Drawing.Point(303, 38);
            this.labWordsAndNumbers.Name = "labWordsAndNumbers";
            this.labWordsAndNumbers.Size = new System.Drawing.Size(107, 13);
            this.labWordsAndNumbers.TabIndex = 4;
            this.labWordsAndNumbers.Text = "Words and Numbers:";
            // 
            // dgvWords
            // 
            this.dgvWords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvWords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Key,
            this.Value});
            this.dgvWords.Location = new System.Drawing.Point(417, 38);
            this.dgvWords.Name = "dgvWords";
            this.dgvWords.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvWords.Size = new System.Drawing.Size(246, 125);
            this.dgvWords.TabIndex = 5;
            // 
            // Key
            // 
            this.Key.HeaderText = "Word";
            this.Key.Name = "Key";
            // 
            // Value
            // 
            this.Value.HeaderText = "Number";
            this.Value.Name = "Value";
            // 
            // labOutput
            // 
            this.labOutput.AutoSize = true;
            this.labOutput.Location = new System.Drawing.Point(47, 206);
            this.labOutput.Name = "labOutput";
            this.labOutput.Size = new System.Drawing.Size(42, 13);
            this.labOutput.TabIndex = 6;
            this.labOutput.Text = "Output:";
            // 
            // tbOutPut
            // 
            this.tbOutPut.Location = new System.Drawing.Point(87, 206);
            this.tbOutPut.Multiline = true;
            this.tbOutPut.Name = "tbOutPut";
            this.tbOutPut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbOutPut.Size = new System.Drawing.Size(576, 309);
            this.tbOutPut.TabIndex = 7;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(47, 139);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 8;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // tbMin
            // 
            this.tbMin.Location = new System.Drawing.Point(132, 32);
            this.tbMin.Name = "tbMin";
            this.tbMin.Size = new System.Drawing.Size(121, 20);
            this.tbMin.TabIndex = 9;
            this.tbMin.Text = "0";
            this.tbMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbMax
            // 
            this.tbMax.Location = new System.Drawing.Point(132, 55);
            this.tbMax.Name = "tbMax";
            this.tbMax.Size = new System.Drawing.Size(121, 20);
            this.tbMax.TabIndex = 10;
            this.tbMax.Text = "0";
            this.tbMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // FizzBuzzForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 543);
            this.Controls.Add(this.tbMax);
            this.Controls.Add(this.tbMin);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.tbOutPut);
            this.Controls.Add(this.labOutput);
            this.Controls.Add(this.dgvWords);
            this.Controls.Add(this.labWordsAndNumbers);
            this.Controls.Add(this.labMaxVal);
            this.Controls.Add(this.labMinVal);
            this.Name = "FizzBuzzForm";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgvWords)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labMinVal;
        private System.Windows.Forms.Label labMaxVal;
        private System.Windows.Forms.Label labWordsAndNumbers;
        private System.Windows.Forms.DataGridView dgvWords;
        private System.Windows.Forms.DataGridViewTextBoxColumn Key;
        private System.Windows.Forms.DataGridViewTextBoxColumn Value;
        private System.Windows.Forms.Label labOutput;
        private System.Windows.Forms.TextBox tbOutPut;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.TextBox tbMin;
        private System.Windows.Forms.TextBox tbMax;
    }
}


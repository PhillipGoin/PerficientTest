﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FizzBuzz;

namespace PerficientFormsVersion
{
    public partial class FizzBuzzForm : Form
    {
        /// <summary>
        /// Initializes the Form.
        /// </summary>
        public FizzBuzzForm()
        {
            InitializeComponent();
            DataGridViewRow row = new DataGridViewRow();
            object[] param = new object[2];
            param[0] = "Fizz";
            param[1] = "3";
            row.CreateCells(this.dgvWords, param);
            DataGridViewRow row1 = new DataGridViewRow();
            object[] param1 = new object[2];
            param1[0] = "Buzz";
            param1[1] = "5";
            row1.CreateCells(this.dgvWords, param1);
            this.dgvWords.Rows.Add(row);
            this.dgvWords.Rows.Add(row1);
            this.tbMax.Text = "15";
            this.tbMin.Text = "1";
        }

        /// <summary>
        /// Handles the btnRun Click Event.
        /// </summary>
        /// <param name="sender">object which initiated the event.</param>
        /// <param name="e">event to be handled.</param>
        private void btnRun_Click(object sender, EventArgs e)
        {
            tbOutPut.Text = "";
            long minVal = 0;
            long maxVal = 0;
            long.TryParse(this.tbMin.Text, out minVal);
            long.TryParse(this.tbMax.Text, out maxVal);
            StringBuilder sb = new StringBuilder();
            Dictionary<string, string> wordNumbers = GetWordNumbers();
            FizzBuzz.FizzBuzzParameters param = new FizzBuzzParameters();
            param.bottom = (int) minVal;
            param.top = (int) maxVal;
            param.words = GetWordNumbers();
            sb = FizzBuzz.FizzBuzz.BatchedFizzBuzz(param);
            tbOutPut.Text = sb.ToString();
        }

        /// <summary>
        /// Used to read the values from the DataGridView
        /// </summary>
        /// <returns>Dictionary of type string, string with the words and numbers.</returns>
        private Dictionary<string, string> GetWordNumbers()
        {
            int rowNum = 1;
            Dictionary<string, string> words = new Dictionary<string, string>();
            foreach (DataGridViewRow r in this.dgvWords.Rows)
            {
                try
                {

                    string word = r.Cells[0].Value.ToString();
                    if (string.IsNullOrEmpty(word))
                    {
                        MessageBox.Show(string.Format("Word can not be empty in row {0}.", rowNum.ToString()));
                    }
                    else
                    {
                        try
                        {
                            words.Add(word, r.Cells[1].Value.ToString());
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(string.Format("Number is not a valid Number in row {0}.", rowNum.ToString()));
                        }
                    }
                }
                catch (Exception ex)
                {

                }
                rowNum += 1;
            }
            return words;
        }
    }
}
